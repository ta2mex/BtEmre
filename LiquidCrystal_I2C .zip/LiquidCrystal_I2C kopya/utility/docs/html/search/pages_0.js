var searchData=
[
  ['readme',['README',['../md___users_fmalpartida__documents_development_mercurial_repos__s_w__newliquid_crystal__r_e_a_d_m_e.html',1,'']]]
];
